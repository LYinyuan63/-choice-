"""Tests for the qianji trading-calendar Router (特色接口, no Standard Model)."""

from datetime import date, datetime, timezone

from fastapi import FastAPI
from fastapi.testclient import TestClient

from qianji_data_mini.db import Database
from qianji_data_mini.models import TradingCalendarDay
from qianji_data_mini.openbb_provider.calendar_router import router, trading_days


def _seed(database_path) -> None:
    database = Database(database_path)
    database.upsert_trading_calendar(
        [
            TradingCalendarDay(
                market="CNSESZ",
                date=date(2026, 9, 1),
                is_open=True,
                previous_open_date=date(2026, 8, 29),
                next_open_date=date(2026, 9, 2),
                fetched_at=datetime.now(timezone.utc),
            ),
            TradingCalendarDay(
                market="CNSESZ",
                date=date(2026, 9, 2),
                is_open=True,
                previous_open_date=date(2026, 9, 1),
                next_open_date=date(2026, 9, 3),
                fetched_at=datetime.now(timezone.utc),
            ),
            TradingCalendarDay(
                market="CNSESZ",
                date=date(2026, 9, 5),  # Saturday, market closed
                is_open=False,
                previous_open_date=date(2026, 9, 4),
                next_open_date=date(2026, 9, 7),
                fetched_at=datetime.now(timezone.utc),
            ),
        ]
    )


def test_trading_days_reads_sqlite_and_filters_open(monkeypatch, tmp_path):
    database_path = tmp_path / "calendar.db"
    _seed(database_path)
    monkeypatch.setenv("QIANJI_DB_PATH", str(database_path))

    obbject = trading_days(
        market="CNSESZ",
        start_date=date(2026, 9, 1),
        end_date=date(2026, 9, 5),
        source="choice",
        is_open=None,
    )
    assert len(obbject.results) == 3
    assert obbject.results[0].market == "CNSESZ"
    assert obbject.results[0].trade_date == date(2026, 9, 1)
    assert obbject.results[0].is_open is True
    assert obbject.results[0].next_open_date == date(2026, 9, 2)

    open_only = trading_days(
        market="CNSESZ",
        start_date=date(2026, 9, 1),
        end_date=date(2026, 9, 5),
        source="choice",
        is_open=True,
    )
    assert len(open_only.results) == 2
    assert all(item.is_open for item in open_only.results)


def test_trading_days_unknown_market_returns_empty_list_not_error(monkeypatch, tmp_path):
    database_path = tmp_path / "calendar_empty.db"
    Database(database_path)  # creates schema, no rows inserted
    monkeypatch.setenv("QIANJI_DB_PATH", str(database_path))

    obbject = trading_days(market="CNSESH")

    assert obbject.results == []


def test_router_is_actually_reachable_over_http(monkeypatch, tmp_path):
    """End-to-end check that the Router wiring itself is correct.

    This mounts the real `router.api_router` (the same object OpenBB's
    RouterLoader mounts under /api/v1/qianji via the openbb_core_extension
    entry point) onto a bare FastAPI app and hits it with a real HTTP
    request, so a broken decorator/annotation would fail this test even if
    the plain Python-level test above still passed.
    """
    database_path = tmp_path / "calendar_http.db"
    _seed(database_path)
    monkeypatch.setenv("QIANJI_DB_PATH", str(database_path))

    app = FastAPI()
    app.include_router(router.api_router)
    client = TestClient(app)

    response = client.get(
        "/calendar/trading_days",
        params={
            "market": "CNSESZ",
            "start_date": "2026-09-01",
            "end_date": "2026-09-05",
        },
    )

    assert response.status_code == 200
    payload = response.json()
    assert len(payload["results"]) == 3
    assert payload["results"][0]["market"] == "CNSESZ"
    assert payload["results"][2]["is_open"] is False
