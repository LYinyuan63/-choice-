"""Custom OpenBB router exposing the qianji trading calendar (特色接口).

`trading_calendar` has no OpenBB Standard Model equivalent (the official
`/equity/calendar/*` routes cover IPO/dividend/split/event/earnings
calendars, not a plain "is this a trading day" market calendar), so it
cannot be registered as a Fetcher under an existing standard route the way
`equity_quote.py` / `equity_historical.py` are. It is registered directly
as a Router via the ``openbb_core_extension`` entry point instead of
``openbb_provider_extension``, which is how OpenBB tells these two kinds
of extensions apart.

IMPORTANT: unlike the Fetcher modules in this package, this file must NOT
use ``from __future__ import annotations``. openbb_core's Router inspects
``func.__annotations__["return"]`` as a real class object (it mutates
``OBBject[...]`` in place), so a deferred/string annotation would break
route registration silently.
"""

from datetime import date, datetime
from typing import Annotated

from fastapi import Query
from openbb_core.app.model.obbject import OBBject
from openbb_core.app.router import Router
from openbb_core.provider.abstract.data import Data
from pydantic import Field

from qianji_data_mini.db import Database

router = Router(prefix="/calendar", description="Qianji SQLite trading calendar.")


class TradingCalendarData(Data):
    """One trading-calendar record read from the qianji SQLite cache."""

    market: str = Field(description="Market code, e.g. CNSESH (SSE) or CNSESZ (SZSE).")
    trade_date: date = Field(description="Calendar date.")
    is_open: bool = Field(description="True if the market is open for trading on this date.")
    previous_open_date: date | None = Field(
        default=None, description="Nearest prior trading day, if available."
    )
    next_open_date: date | None = Field(
        default=None, description="Nearest following trading day, if available."
    )
    source: str = Field(default="choice", description="Vendor the calendar was ingested from.")
    timezone: str = Field(default="Asia/Shanghai", description="Timezone of trade_date.")
    fetched_at: datetime = Field(description="UTC timestamp the record was last ingested.")


def _clean(value: object) -> object | None:
    """Turn pandas NaN/NaT into None; leave everything else untouched."""
    if value is None:
        return None
    try:
        if value != value:  # NaN/NaT are the only values unequal to themselves
            return None
    except (TypeError, ValueError):
        pass
    return value


@router.command(methods=["GET"])
def trading_days(
    market: Annotated[
        str, Query(description="Market code to filter on, e.g. CNSESH or CNSESZ.")
    ],
    start_date: Annotated[
        date | None,
        Query(description="Inclusive start date. Defaults to the earliest cached date."),
    ] = None,
    end_date: Annotated[
        date | None,
        Query(description="Inclusive end date. Defaults to the latest cached date."),
    ] = None,
    source: Annotated[
        str, Query(description="Vendor whose calendar was cached, e.g. choice.")
    ] = "choice",
    is_open: Annotated[
        bool | None,
        Query(description="Optionally keep only open (true) or closed (false) days."),
    ] = None,
) -> OBBject[list[TradingCalendarData]]:
    """Read the Choice trading calendar cached in the qianji SQLite database.

    This is a 特色接口 (feature-specific endpoint): it has no OpenBB
    Standard Model, so it reads straight from SQLite via
    ``Database.query_trading_calendar`` instead of going through a
    Fetcher/Provider. It never calls the Choice API and consumes no vendor
    quota; the data must already have been ingested (see
    ``reference_ingest.ingest_choice_reference``).

    Unlike ``= Query(...)`` used as a plain default, the ``Annotated[...]``
    form here keeps the *real* default (``None`` / ``"choice"``) as the
    actual Python default, so this function behaves the same whether it is
    called through FastAPI/HTTP or imported and called directly, e.g. from
    a notebook: ``trading_days(market="CNSESZ")``.
    """
    frame = Database().query_trading_calendar(
        market=market,
        start_date=start_date,
        end_date=end_date,
        source=source,
    )
    if not frame.empty and is_open is not None:
        frame = frame[frame["is_open"].astype(bool) == is_open]
    if frame.empty:
        return OBBject(results=[])

    results = [
        TradingCalendarData(
            market=str(row["market"]),
            trade_date=row["trade_date"],
            is_open=bool(row["is_open"]),
            previous_open_date=_clean(row.get("previous_open_date")),
            next_open_date=_clean(row.get("next_open_date")),
            source=str(row.get("source") or "choice"),
            timezone=str(row.get("timezone") or "Asia/Shanghai"),
            fetched_at=row["fetched_at"],
        )
        for row in frame.to_dict("records")
    ]
    return OBBject(results=results)
